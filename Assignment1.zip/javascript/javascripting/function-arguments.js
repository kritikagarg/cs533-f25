function math(a, b, c) {
  return a + (b * c);
}

console.log(math(53, 61, 67));
