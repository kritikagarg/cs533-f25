const fruit = 'orange';

if (fruit.length > 5) {
    console.log('name has more than five characters.');
} else {
    console.log(' name has five characters or less.');
}
